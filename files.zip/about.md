---
layout: page
title: About
permalink: /about/
---

# About Me

I'm a cybersecurity professional passionate about defending digital infrastructure and staying one step ahead of emerging threats.

## Background

<!-- Add your background here - education, how you got into security, etc. -->

Coming soon...

## Certifications

<!-- List your certs here, for example: -->
<!-- - CISSP -->
<!-- - CEH -->
<!-- - Security+ -->
<!-- - OSCP -->

Coming soon...

## Beyond Security

When I'm not hunting threats or hardening systems, you'll find me:

- 🎮 Gaming
- 🎵 Listening to music
- 🐕 Spending time with my dog
- 🏈 Watching sports
- 💰 Following the crypto space

---

## Contact

The best way to reach me is through [LinkedIn](#) or [GitHub](https://github.com/JustinGold-infosec).
