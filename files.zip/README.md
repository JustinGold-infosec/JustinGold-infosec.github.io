# JustinGold-infosec.github.io

Personal cybersecurity portfolio and blog.

Built with [Jekyll](https://jekyllrb.com/) and hosted on [GitHub Pages](https://pages.github.com/).

## Local Development

```bash
bundle install
bundle exec jekyll serve
```

Then visit `http://localhost:4000`
