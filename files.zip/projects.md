---
layout: page
title: Projects
permalink: /projects/
---

# Projects & Write-ups

A collection of security projects, CTF write-ups, and tools I've built or contributed to.

---

## Tools & Scripts

<!-- Add your tools/scripts here -->

*Coming soon...*

---

## CTF Write-ups

<!-- Add CTF write-ups here -->

*Coming soon...*

---

## Research & Articles

<!-- Add any security research or blog posts -->

*Coming soon...*

---

*Check back soon or follow me on [GitHub](https://github.com/JustinGold-infosec) for updates.*
